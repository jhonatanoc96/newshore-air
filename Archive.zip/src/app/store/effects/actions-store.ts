import { createAction } from '@ngrx/store';

export const origin = createAction('setOrigin');
export const destination = createAction('setDestination');