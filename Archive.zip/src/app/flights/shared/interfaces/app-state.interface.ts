export interface AppState {
    origin: string,
    destination: string
}