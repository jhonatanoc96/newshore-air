export interface Transport {
    flightCarrier: string,
    flightNumber: string
}