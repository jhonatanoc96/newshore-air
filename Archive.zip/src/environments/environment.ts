export const environment = {
    TOKEN: 'my-token',
    URL: 'https://recruiting-api.newshore.es/api/flights'
}